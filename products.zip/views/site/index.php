<?php

/* @var $this yii\web\View */

$this->title = 'Product Uploader';
?>
<div class="site-index">

    <div class="body-content">
        <h3>Hello!</h3>

        <p>Click on the "Products" link in the navigation bar above to CRUD products.</p>
        <p>Log in to create/update a product.</p>
    </div>

</div>

<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "products".
 *
 * @property int $id
 * @property string $code
 * @property string $name
 * @property string $description
 * @property int $quantity
 * @property string $price
 * @property string $imageFile
 */
class Products extends \yii\db\ActiveRecord
{
    /**
     * @var UploadedFile
     */
    public $instance;

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'products';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'name', 'quantity', 'price'], 'required'],
            [['description'], 'string'],
            [['quantity'], 'integer'],
            [['price'], 'number'],
            [['code'], 'string', 'max' => 10],
            [['name'], 'string', 'max' => 100],
            [['instance'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'code' => 'Product Code',
            'name' => 'Product Name',
            'description' => 'Description',
            'quantity' => 'Quantity',
            'price' => 'Price',
            'imageFile' => 'Photo',
        ];
    }
    
    public function upload()
    {
        if ($this->validate()) {
            $filePath = 'uploads/' . $this->instance->baseName . '.' . $this->instance->extension;
            
            if ($this->instance->saveAs($filePath)) {
                $this->imageFile = $filePath;
                return true;
            }
        } else {
            return false;
        }
    }
}

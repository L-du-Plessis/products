<?php

return [
    'adminEmail' => 'louhelmdp@gmail.com',
];
